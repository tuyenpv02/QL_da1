/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Application;

import Views.DangNhapForm;
import Views.QuanLyFrame;

/**
 *
 * @author TBC
 */
public class Main {
    public static void main(String[] args) {
        
         // TODO code application logic here
        DangNhapForm q=new DangNhapForm();
        q.setVisible(true);
        q.setLocationRelativeTo(null);
    }
    
}
