/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModels;

/**
 *
 * @author TBC
 */
public class ThongKeThangViewModels {
    private double doanhThu;
    private int tongHD;
    private int hoaDonHuy;
    private int hoaDonThanhCong;

    public double getDoanhThu() {
        return doanhThu;
    }

    public void setDoanhThu(double doanhThu) {
        this.doanhThu = doanhThu;
    }

    public int getTongHD() {
        return tongHD;
    }

    public void setTongHD(int tongHD) {
        this.tongHD = tongHD;
    }

    public int getHoaDonHuy() {
        return hoaDonHuy;
    }

    public void setHoaDonHuy(int hoaDonHuy) {
        this.hoaDonHuy = hoaDonHuy;
    }

    public int getHoaDonThanhCong() {
        return hoaDonThanhCong;
    }

    public void setHoaDonThanhCong(int hoaDonThanhCong) {
        this.hoaDonThanhCong = hoaDonThanhCong;
    }
    
    
}
